'use strict';

/**
 * @ngdoc service
 * @name moviemaniaApp.MovieList
 * @description
 * # MovieList
 * Value in the moviemaniaApp.
 */
angular.module('moviemaniaApp')
  .value('MovieList', 42);
