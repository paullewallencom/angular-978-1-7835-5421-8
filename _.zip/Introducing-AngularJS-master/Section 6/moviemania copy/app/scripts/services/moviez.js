'use strict';

/**
 * @ngdoc service
 * @name moviemaniaApp.Moviez
 * @description
 * # Moviez
 * Service in the moviemaniaApp.
 */
angular.module('moviemaniaApp')
  .service('Moviez', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
