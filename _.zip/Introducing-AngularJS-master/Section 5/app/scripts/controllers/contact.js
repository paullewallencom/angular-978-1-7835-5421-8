'use strict';

/**
 * @ngdoc function
 * @name moviemaniaApp.controller:ContactCtrl
 * @description
 * # ContactCtrl
 * Controller of the moviemaniaApp
 */
angular.module('moviemaniaApp')
  .controller('ContactCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
