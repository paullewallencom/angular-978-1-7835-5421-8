# MovieMania

Companion code for the Packt "Rapid Angular" course.

## Requirements
You need to have node and npm installed.
Bower needs to be installed globally

## Getting started

From a command line:

### Clone repository

```
  git clone https://github.com/matiboy/moviemania.git
  cd moviemania
```

### Install node depencies

```
  npm install
```

### Install bower dependencies
```
  bower install
```
